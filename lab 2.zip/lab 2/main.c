#include <stdio.h>
extern long long int lab02d(long long int a);

int main(void)
{
  printf(lab02d(69));
    return 0;
}
